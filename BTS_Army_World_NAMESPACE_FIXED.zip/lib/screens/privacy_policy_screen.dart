import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {

  const PrivacyPolicyScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("Privacy Policy"),

        backgroundColor: Colors.purple,

      ),

      body: const Padding(

        padding: EdgeInsets.all(20),

        child: SingleChildScrollView(

          child: Text(

"""

BTS Army World respects your privacy.

• We do not collect personal information without your permission.

• Images are loaded from online sources.

• Ads may be shown using Google AdMob.

• Favorites are stored only on your device.

""",

style: TextStyle(fontSize:16),

),

),

),

);

}

}