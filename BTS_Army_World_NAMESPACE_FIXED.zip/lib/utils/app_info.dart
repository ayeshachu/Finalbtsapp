class AppInfo {

static const version="1.0.0";

static const developer="Shafqat Nasir";

}