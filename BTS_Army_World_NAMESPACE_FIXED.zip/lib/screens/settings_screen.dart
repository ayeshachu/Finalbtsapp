import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {

  const SettingsScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("Settings"),

        backgroundColor: Colors.purple,

      ),

      body: ListView(

        children: const [

          ListTile(

            leading: Icon(Icons.dark_mode),

            title: Text("Dark Mode"),

            subtitle: Text("Coming Soon"),

          ),

          Divider(),

          ListTile(

            leading: Icon(Icons.notifications),

            title: Text("Notifications"),

            subtitle: Text("Coming Soon"),

          ),

          Divider(),

          ListTile(

            leading: Icon(Icons.cleaning_services),

            title: Text("Clear Cache"),

          ),

          Divider(),

          ListTile(

            leading: Icon(Icons.language),

            title: Text("Language"),

            subtitle: Text("English"),

          ),

        ],

      ),

    );

  }

}