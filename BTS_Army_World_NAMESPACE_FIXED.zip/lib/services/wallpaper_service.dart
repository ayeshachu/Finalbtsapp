import 'dart:io';

import 'package:flutter_wallpaper_manager/flutter_wallpaper_manager.dart';
import 'package:permission_handler/permission_handler.dart';

class WallpaperService {

  static Future<bool> setHomeWallpaper(File file) async {

    await Permission.photos.request();

    int location = WallpaperManager.HOME_SCREEN;

    return await WallpaperManager.setWallpaperFromFile(
      file.path,
      location,
    );
  }

  static Future<bool> setLockWallpaper(File file) async {

    await Permission.photos.request();

    int location = WallpaperManager.LOCK_SCREEN;

    return await WallpaperManager.setWallpaperFromFile(
      file.path,
      location,
    );
  }

  static Future<bool> setBothWallpaper(File file) async {

    await Permission.photos.request();

    int location = WallpaperManager.BOTH_SCREEN;

    return await WallpaperManager.setWallpaperFromFile(
      file.path,
      location,
    );
  }
}