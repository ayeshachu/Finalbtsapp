import 'package:flutter/material.dart';

import 'gallery_screen.dart';

class SearchScreen extends StatefulWidget {

  const SearchScreen({super.key});

  @override

  State<SearchScreen> createState() => _SearchScreenState();

}

class _SearchScreenState extends State<SearchScreen> {

  final List<Map<String, dynamic>> allCategories = [

    {"title":"BTS Cute","category":"bts_cute","quotes":false},

    {"title":"BTS Aesthetic","category":"bts_aesthetic","quotes":false},

    {"title":"BTS Arrirang","category":"bts_arrirang","quotes":false},

    {"title":"JK Cute","category":"jk_cute","quotes":false},

    {"title":"JK Hot","category":"jk_hot","quotes":false},

    {"title":"JK Eyes","category":"jk_eyes","quotes":false},

    {"title":"V Cute","category":"v_cute","quotes":false},

    {"title":"V Hot","category":"v_hot","quotes":false},

    {"title":"V Aesthetic","category":"v_aesthetic","quotes":false},

    {"title":"Jimin Cute","category":"jimin_cute","quotes":false},

    {"title":"Suga AgustD","category":"suga_agustd","quotes":false},

    {"title":"BTS Quotes","category":"bts_quotes","quotes":true},

    {"title":"JK Quotes","category":"jk_quotes","quotes":true},

    {"title":"V Quotes","category":"v_quotes","quotes":true},

    {"title":"RM Quotes","category":"rm_quotes","quotes":true},

    {"title":"Jhope Quotes","category":"jhope_quotes","quotes":true},

    {"title":"Jin Quotes","category":"jin_quotes","quotes":true},

    {"title":"Jimin Quotes","category":"jimin_quotes","quotes":true},

    {"title":"Suga Quotes","category":"suga_quotes","quotes":true},

  ];

  List<Map<String,dynamic>> result=[];

  @override

  void initState() {
      super.initState();

    result=allCategories;

  }
    
  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("Search"),

        backgroundColor: Colors.purple,

      ),
        
      body: Column(

        children: [

          Padding(

            padding: const EdgeInsets.all(12),

            child: TextField(

              decoration: const InputDecoration(

                hintText: "Search BTS...",

                prefixIcon: Icon(Icons.search),

              ),
             onChanged: (value){

                setState(() {

                  result=allCategories.where((e){

                    return e["title"]

                        .toLowerCase()

                        .contains(value.toLowerCase());

                  }).toList();

                });

              },

            ),

          ),   
          
                   Expanded(

            child: ListView.builder(

              itemCount: result.length,

              itemBuilder: (context,index){

                return ListTile(

                  leading: const Icon(Icons.image),
                    
                  title: Text(result[index]["title"]),

                  trailing: const Icon(Icons.arrow_forward_ios),

                  onTap: (){

                    Navigator.push(context,

                      MaterialPageRoute(

                        builder:(_)=>GalleryScreen(
                            title: result[index]["title"],

                          category: result[index]["category"],

                          isQuotes: result[index]["quotes"],

                        ),

                      ),

                    );

                  },

                );

              },

            ),

          ),

        ],

      ),

    );

  }

}