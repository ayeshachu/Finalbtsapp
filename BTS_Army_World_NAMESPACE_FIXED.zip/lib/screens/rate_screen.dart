import 'package:flutter/material.dart';

class RateScreen extends StatelessWidget {

  const RateScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return AlertDialog(

      title: const Text("Rate BTS Army World"),

      content: const Text(

        "If you enjoy using the app, please rate it when it is published on the Play Store. 💜",

      ),

      actions: [

        TextButton(

          onPressed: (){

            Navigator.pop(context);

          },

          child: const Text("Later"),

        ),

        ElevatedButton(

          onPressed: (){

            Navigator.pop(context);

          },

          child: const Text("Rate"),

        ),

      ],

    );

  }

}