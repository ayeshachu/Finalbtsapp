import 'package:flutter/material.dart';

class FeedbackScreen extends StatefulWidget {

  const FeedbackScreen({super.key});

  @override

  State<FeedbackScreen> createState() => _FeedbackScreenState();

}

class _FeedbackScreenState extends State<FeedbackScreen> {

  final controller = TextEditingController();

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        backgroundColor: Colors.purple,

        title: const Text("Feedback"),

      ),

      body: Padding(

        padding: const EdgeInsets.all(20),

        child: Column(

          children: [

            TextField(

              controller: controller,

              maxLines: 6,

              decoration: InputDecoration(

                hintText: "Write your feedback...",

                border: OutlineInputBorder(

                  borderRadius: BorderRadius.circular(15),

                ),

              ),

            ),

            const SizedBox(height:25),

            SizedBox(

              width: double.infinity,
                
              child: ElevatedButton(

                onPressed: (){

                  ScaffoldMessenger.of(context).showSnackBar(

                    const SnackBar(

                      content: Text("Thank you 💜"),

                    ),

                  );

                },

                child: const Text("Submit"),

              ),

            ),

          ],

        ),

      ),

    );

  }

}