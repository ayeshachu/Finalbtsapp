import 'package:flutter/material.dart';

class AppTheme {

  static ThemeData light = ThemeData(

    useMaterial3: true,

    colorSchemeSeed: Colors.purple,

    scaffoldBackgroundColor: Colors.white,

    appBarTheme: const AppBarTheme(

      centerTitle: true,

      backgroundColor: Colors.purple,

      foregroundColor: Colors.white,

    ),

  );

}