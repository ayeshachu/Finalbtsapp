import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:share_plus/share_plus.dart';

class ShareDownloadService {
  static Future<File> _download(String url) async {
    Directory dir = await getTemporaryDirectory();

    String path =
        "${dir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg";

    await Dio().download(url, path);

    return File(path);
  }

  static Future<void> downloadImage(String url) async {
    File file = await _download(url);

    await GallerySaver.saveImage(file.path);
  }

  static Future<void> shareImage(String url) async {
    File file = await _download(url);

    await Share.shareXFiles([
      XFile(file.path),
    ]);
  }
}