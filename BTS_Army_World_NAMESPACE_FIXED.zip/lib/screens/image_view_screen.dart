import '../services/favorite_service.dart';

import 'package:flutter/material.dart';

import 'package:photo_view/photo_view.dart';

import '../services/share_download_service.dart';

class ImageViewScreen extends StatefulWidget {

  final String imageUrl;

  const ImageViewScreen({

    super.key,

    required this.imageUrl,

  });

    

  @override

  State<ImageViewScreen> createState() => _ImageViewScreenState();

}

class _ImageViewScreenState extends State<ImageViewScreen> {

  bool isFav = false;

  @override

  void initState() {

    super.initState();

    loadFav();

  }

  void loadFav() async {

    isFav = await FavoriteService.isFavorite(widget.imageUrl);

    setState(() {});

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.black,

      appBar: AppBar(

        backgroundColor: Colors.black,

        iconTheme: const IconThemeData(color: Colors.white),

        actions: [

          // Share Button

          IconButton(

            icon: const Icon(Icons.share),

            onPressed: () async {

              await ShareDownloadService.shareImage(widget.imageUrl);

              ScaffoldMessenger.of(context).showSnackBar(

                const SnackBar(

                  content: Text("Image Shared"),

                       ),

              );

            },

          ),

          // favorite button 

          IconButton(

            icon: Icon(

              isFav ? Icons.favorite : Icons.favorite_border,

              color: Colors.red,

            ),

            onPressed: () async {

              if (isFav) {

                await FavoriteService.removeFavorite(widget.imageUrl);

              } else {

                await FavoriteService.addFavorite(widget.imageUrl);

              }

              loadFav();

            },

          ),

          // Download button 
          IconButton(

            icon: const Icon(Icons.download),

            onPressed: () async {

              await ShareDownloadService.downloadImage(widget.imageUrl);

              ScaffoldMessenger.of(context).showSnackBar(

                const SnackBar(

                  content: Text("Image Saved to Gallery"),

                ),

              );

            },

          ),

        ],

      ),

      body: Hero(

        tag: widget.imageUrl,

        child: PhotoView(

          imageProvider: NetworkImage(widget.imageUrl),

          backgroundDecoration: const BoxDecoration(color: Colors.black),

          minScale: PhotoViewComputedScale.contained,

          maxScale: PhotoViewComputedScale.covered * 3,

        ),

      ),

    );

  }

}