import 'package:shared_preferences/shared_preferences.dart';

class FavoriteService {
  static const String key = "favorites";

  static Future<List<String>> getFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(key) ?? [];
  }

  static Future<bool> isFavorite(String image) async {
    final list = await getFavorites();
    return list.contains(image);
  }

  static Future<void> addFavorite(String image) async {
    final prefs = await SharedPreferences.getInstance();

    List<String> list = prefs.getStringList(key) ?? [];

    if (!list.contains(image)) {
      list.add(image);
    }

    await prefs.setStringList(key, list);
  }

  static Future<void> removeFavorite(String image) async {
    final prefs = await SharedPreferences.getInstance();

    List<String> list = prefs.getStringList(key) ?? [];

    list.remove(image);

    await prefs.setStringList(key, list);
  }
}