import 'package:flutter/material.dart';

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

          CircularProgressIndicator(),

          SizedBox(height: 15),

          Text(
            "Loading BTS Images...",
            style: TextStyle(fontSize: 16),
          ),

        ],
      ),
    );
  }
}