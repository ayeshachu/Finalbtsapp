import 'dart:async'; //add karte hi tumhara compile error khatam
import 'package:flutter/material.dart';

import 'home_screen.dart';

class SplashScreen extends StatefulWidget {

  const SplashScreen({super.key});

  @override

  State<SplashScreen> createState() => _SplashScreenState();

}

class _SplashScreenState extends State<SplashScreen> {

  @override

  void initState() {

    super.initState();

    Timer(const Duration(seconds: 3), () {

      Navigator.pushReplacement(

        context,

        MaterialPageRoute(

          builder: (_) => const HomeScreen(),

        ),

      );

    });

  }
    @override

  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: const Color(0xff6A1B9A),

      body: Center(

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: const [

            Icon(

              Icons.favorite,

              color: Colors.white,

              size: 90,

            ),

            SizedBox(height: 20),

            Text(

              "BTS Army World",

              style: TextStyle(

                color: Colors.white,

                fontSize: 30,

                fontWeight: FontWeight.bold,

              ),

            ),

            SizedBox(height: 10),
              
              Text(

              "Made For ARMY 💜",

              style: TextStyle(

                color: Colors.white70,

                fontSize: 18,

              ),

            ),

            SizedBox(height: 40),

            CircularProgressIndicator(

              color: Colors.white,

            ),

          ],

        ),

      ),

    );

  }

}
              