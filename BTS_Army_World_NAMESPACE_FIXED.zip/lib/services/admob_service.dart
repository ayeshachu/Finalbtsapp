class AdMobService {
  // Real AdMob Banner Ad Unit ID
  static String get bannerAdUnitId =>
      "ca-app-pub-7880063072346830/2064790044";

  // Real AdMob Interstitial Ad Unit ID
  static String get interstitialAdUnitId =>
      "ca-app-pub-7880063072346830/1817378031";

  // Real AdMob Rewarded Ad Unit ID
  static String get rewardedAdUnitId =>
      "ca-app-pub-7880063072346830/5996743302";
}
