import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../services/admob_service.dart';

class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() =>
      _BannerAdWidgetState();
}

class _BannerAdWidgetState
    extends State<BannerAdWidget> {

  BannerAd? banner;

  @override
  void initState() {
    super.initState();

    banner = BannerAd(
      size: AdSize.banner,
      adUnitId: AdMobService.bannerAdUnitId,
      listener: BannerAdListener(),
      request: const AdRequest(),
    )..load();
  }

  @override
  Widget build(BuildContext context) {

    if (banner == null) {
      return const SizedBox();
    }

    return SizedBox(
      width: banner!.size.width.toDouble(),
      height: banner!.size.height.toDouble(),
      child: AdWidget(ad: banner!),
    );
  }

  @override
  void dispose() {
    banner?.dispose();
    super.dispose();
  }
}