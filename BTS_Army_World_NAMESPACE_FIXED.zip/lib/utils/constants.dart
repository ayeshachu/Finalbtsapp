class AppConstants {

  static const appName = "BTS Army World";

  static const wallpaperTitle = "Wallpapers";

  static const quotesTitle = "Quotes";

}