import 'package:flutter/material.dart';

import 'subcategory_screen.dart';

import 'gallery_screen.dart';

class WallpaperMenu extends StatelessWidget {

  const WallpaperMenu({super.key});

  @override

  Widget build(BuildContext context) {

    final List<Map<String, dynamic>> categories = [

      {

        "title": "BTS Wallpaper",

        "subs": ["Cute", "Aesthetic", "Arrirang"],

        "direct": false,

      },

      {

        "title": "JK Wallpaper",

        "subs": ["Cute", "Hot", "Eyes", "Aesthetic"],

        "direct": false,

      },

      {

        "title": "V Wallpaper",

        "subs": ["Cute", "Hot", "Aesthetic"],

        "direct": false,

      },

      {

        "title": "Jimin Wallpaper",

        "subs": ["Cute", "Hot", "Aesthetic"],

        "direct": false,

      },

      {

        "title": "Suga Wallpaper",

        "subs": ["Cute", "AgustD", "Aesthetic"],

        "direct": false,

      },

      {

        "title": "Jhope Wallpaper",

        "subs": ["Cute", "Hot", "Aesthetic"],

        "direct": false,

      },

      {

        "title": "RM Wallpaper",

        "subs": ["Cute", "Hot", "Aesthetic"],

        "direct": false,

      },

      {

        "title": "Jin Wallpaper",

        "subs": ["Cute", "Hot", "Aesthetic"],

        "direct": false,

      },

      // =========================

      // COUPLES / SHIPPING

      // Direct Gallery

      // =========================

      {

        "title": "Taekook Wallpaper",

        "direct": true,

      },

      {

        "title": "Yoonmin Wallpaper",

        "direct": true,

      },

      {

        "title": "Namjin Wallpaper",

        "direct": true,

      },

      {

        "title": "Yoonkook Wallpaper",

        "direct": true,

      },

      {

        "title": "Jikook Wallpaper",

        "direct": true,

      },

      {

        "title": "Jinkook Wallpaper",

        "direct": true,

      },

      {

        "title": "Jinmin Wallpaper",

        "direct": true,

      },

      {

        "title": "Vmin Wallpaper",

        "direct": true,

      },

      {

        "title": "Vjin Wallpaper",

        "direct": true,

      },

    ];

    return Scaffold(

      appBar: AppBar(

        title: const Text(

          "Wallpaper Categories",

          style: TextStyle(

            color: Colors.white,

          ),

        ),

        centerTitle: true,

        backgroundColor: Colors.purple,

      ),

      body: Padding(

        padding: const EdgeInsets.all(12),

        child: GridView.builder(

          itemCount: categories.length,

          gridDelegate:

              const SliverGridDelegateWithFixedCrossAxisCount(

            crossAxisCount: 2,

            crossAxisSpacing: 12,

            mainAxisSpacing: 12,

            childAspectRatio: 1.35,

          ),

          itemBuilder: (context, index) {

            final item = categories[index];

            final String title = item["title"];

            final bool direct = item["direct"] ?? false;

            return ElevatedButton(

              style: ElevatedButton.styleFrom(

                backgroundColor: Colors.purple,

                shape: RoundedRectangleBorder(

                  borderRadius: BorderRadius.circular(18),

                ),

              ),

              onPressed: () {

                // ==========================================

                // COUPLES:

                // DIRECTLY OPEN GALLERY

                // ==========================================

                if (direct) {

                  final String category = title

                      .replaceAll(

                        ' Wallpaper',

                        '',

                      )

                      .replaceAll(

                        ' ',

                        '',

                      )

                      .toLowerCase();

                  Navigator.push(

                    context,

                    MaterialPageRoute(

                      builder: (_) => GalleryScreen(

                        title: title,

                        category: category,

                        isQuotes: false,

                      ),

                    ),

                  );

                  return;

                }

                // ==========================================

                // MEMBER CATEGORIES:

                // OPEN SUBCATEGORY SCREEN

                // ==========================================

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (_) => SubCategoryScreen(

                      title: title,

                      subCategories:

                          List<String>.from(

                        item["subs"] ?? [],

                      ),

                    ),

                  ),

                );

              },

              child: Text(

                title,

                textAlign: TextAlign.center,

                style: const TextStyle(

                  color: Colors.white,

                  fontWeight: FontWeight.bold,

                  fontSize: 17,

                ),

              ),

            );

          },

        ),

      ),

    );

  }

}    