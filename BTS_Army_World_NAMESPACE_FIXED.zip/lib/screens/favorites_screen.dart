import 'package:flutter/material.dart';

import 'package:cached_network_image/cached_network_image.dart';

import '../services/favorite_service.dart';

import 'image_view_screen.dart';

class FavoritesScreen extends StatefulWidget {

  const FavoritesScreen({super.key});

  @override

  State<FavoritesScreen> createState() => _FavoritesScreenState();

}

class _FavoritesScreenState extends State<FavoritesScreen> {

  List<String> favorites = [];

  @override

  void initState() {

    super.initState();

    loadFavorites();

  }

  Future<void> loadFavorites() async {

    favorites = await FavoriteService.getFavorites();

    setState(() {});

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("Favorites"),

        backgroundColor: Colors.purple,

      ),

      body: favorites.isEmpty

          ? const Center(

              child: Text("No Favorites Yet"),

            )

          : GridView.builder(

              padding: const EdgeInsets.all(10),

              itemCount: favorites.length,

              gridDelegate:

                  const SliverGridDelegateWithFixedCrossAxisCount(

                crossAxisCount: 2,

                crossAxisSpacing: 10,

                mainAxisSpacing: 10,

              ),

              itemBuilder: (context, index) {

                return InkWell(

                  onTap: () {

                    Navigator.push(

                      context,

                      MaterialPageRoute(

                        builder: (_) => ImageViewScreen(

                          imageUrl: favorites[index],

                        ),

                      ),

                    ).then((_) => loadFavorites());

                  },

                  child: ClipRRect(

                    borderRadius: BorderRadius.circular(15),

                    child: CachedNetworkImage(

                      imageUrl: favorites[index],

                      fit: BoxFit.cover,

                    ),

                  ),

                );

              },

            ),

    );

  }

}