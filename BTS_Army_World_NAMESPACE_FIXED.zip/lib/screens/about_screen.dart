import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {

  const AboutScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("About"),

        backgroundColor: Colors.purple,

      ),

      body: const Padding(

        padding: EdgeInsets.all(20),

        child: Column(

          children: [

            CircleAvatar(

  radius: 45,

  backgroundImage: AssetImage("assets/images/logo.png"),

),

            SizedBox(height: 20),

            Text(

              "BTS Army World",

              style: TextStyle(

                fontSize: 25,

                fontWeight: FontWeight.bold,

              ),

            ),

            SizedBox(height: 10),

            Text(

              "Made with 💜 for BTS ARMY",

              textAlign: TextAlign.center,

            ),

            SizedBox(height: 25),

            Text(
              "AppInfo.version",

              style: TextStyle(fontSize: 18),

            ),

            const SizedBox(height: 30),

Text(

  "Developed for BTS fans to enjoy wallpapers, quotes and more in one place.",

  textAlign: TextAlign.center,

),

          ],

        ),

      ),

    );

  }

}