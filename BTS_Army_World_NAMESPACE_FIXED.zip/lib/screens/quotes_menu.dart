import 'package:flutter/material.dart';

import 'gallery_screen.dart';

class QuotesMenu extends StatelessWidget {

  const QuotesMenu({super.key});

  @override

  Widget build(BuildContext context) {

    final quotes = [

      "BTS Quotes",

      "JK Quotes",

      "V Quotes",

      "Jin Quotes",

      "Jimin Quotes",

      "Suga Quotes",

      "RM Quotes",

      "Jhope Quotes",

    ];

    return Scaffold(

      appBar: AppBar(

        title: const Text(

          "Quotes",

          style: TextStyle(color: Colors.white),

        ),

        backgroundColor: Colors.purple,

      ),
      body: GridView.builder(

        padding: const EdgeInsets.all(12),

        itemCount: quotes.length,

        gridDelegate:

            const SliverGridDelegateWithFixedCrossAxisCount(

          crossAxisCount: 2,

          crossAxisSpacing: 10,

          mainAxisSpacing: 10,

        ),

        itemBuilder: (context, index) {

          return ElevatedButton(

            style: ElevatedButton.styleFrom(

              backgroundColor: Colors.deepPurple,

            ),

            onPressed: () {

              String category = quotes[index]

                  .replaceAll(" Quotes", "")
                    .replaceAll(" ", "")

                  .toLowerCase();

              Navigator.push(

                context,

                MaterialPageRoute(

                  builder: (_) => GalleryScreen(

                    title: quotes[index],

                    category: "${category}_quotes",

                    isQuotes: true,

                  ),

                ),

              );

            },

            child: Text(

              quotes[index],

              textAlign: TextAlign.center,

              style: const TextStyle(

                color: Colors.white,

                fontWeight: FontWeight.bold,

              ),

            ),

          );

        },

      ),

    );

  }

}