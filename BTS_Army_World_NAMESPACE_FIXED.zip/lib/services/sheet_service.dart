import 'dart:convert';

import 'package:http/http.dart' as http;

class SheetService {

  static const String wallpaperSheet =

      "https://docs.google.com/spreadsheets/d/1Tpn5O-caatWYvnIGrzAr3uoefErXT2-j6qyaaiaYpCc/export?format=csv";

  static const String quotesSheet =

      "https://docs.google.com/spreadsheets/d/1nSFYXpZWqlPJJkvA8Bid1Mf4KCQx8p3ROw-a08PHV_A/export?format=csv";

  Future<List<String>> getImages(String category, bool isQuotes) async {

    final url = isQuotes ? quotesSheet : wallpaperSheet;

    final response = await http.get(Uri.parse(url));

    if (response.statusCode != 200) {

      return [];

    }

    final rows = const LineSplitter().convert(response.body);

    List<String> images = [];

    for (int i = 1; i < rows.length; i++) {

      final cols = rows[i].split(",");

      if (cols.length >= 2) {

        if (cols[0].trim().toLowerCase() ==

            category.trim().toLowerCase()) {

          images.add(cols[1].trim());

        }

      }

    }

    return images;

  }

}