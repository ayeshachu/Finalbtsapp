import 'package:flutter/material.dart';

import 'package:url_launcher/url_launcher.dart';

class ContactScreen extends StatelessWidget {

  const ContactScreen({super.key});

  Future<void> openEmail() async {

    final Uri email = Uri(

      scheme: "mailto",

      path: "your_email@gmail.com",

      query: "subject=BTS Army World Feedback",

    );

    await launchUrl(email);

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("Contact Us"),

        backgroundColor: Colors.purple,

      ),

      body: ListView(

        children: [

          ListTile(

            leading: const Icon(Icons.email),

            title: const Text("Email"),

            subtitle:

                const Text("ayeshachu324@gmail.com"),

            onTap: openEmail,

          ),

        ],

      ),

    );

  }

}