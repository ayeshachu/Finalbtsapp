package com.ayeshachu.btsarmywallpaper

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
