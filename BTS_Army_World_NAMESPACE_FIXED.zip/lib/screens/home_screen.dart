import 'package:flutter/material.dart';
import 'gallery_screen.dart';

import 'rate_screen.dart';

import '../widgets/custom_drawer.dart';

import 'search_screen.dart';

import 'favorites_screen.dart';

import 'package:flutter/material.dart';

import 'wallpaper_menu.dart';

import 'quotes_menu.dart';

class HomeScreen extends StatelessWidget {

  const HomeScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

          actions: [

  IconButton(

icon:const Icon(Icons.star),

onPressed:(){

showDialog(

context: context,

builder:(_)=>const RateScreen(),

);

},

),

  IconButton(

  icon: const Icon(Icons.search),
  onPressed: (){

    Navigator.push(

      context,

      MaterialPageRoute(

        builder: (_)=>const SearchScreen(),

      ),

    );

  },

),
     IconButton(

    icon: const Icon(Icons.favorite),

    onPressed: () {

      Navigator.push(

        context,

        MaterialPageRoute(

          builder: (_) => const FavoritesScreen(),

        ),

      );

    },

  ),

],
          title: const Text(

          "BTS Army World",

          style: TextStyle(color: Colors.white),

        ),

        backgroundColor: Colors.purple,

        centerTitle: true,

      ),

      drawer: const CustomDrawer(),

      body: Padding(

        padding: const EdgeInsets.all(20),

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            SizedBox(

              width: double.infinity,

              height: 120,

              child: ElevatedButton.icon(

                icon: const Icon(Icons.wallpaper,
                    color: Colors.white,

                    size: 35),

                label: const Text(

                  "BTS Wallpapers",

                  style: TextStyle(

                    color: Colors.white,

                    fontSize: 24,

                    fontWeight: FontWeight.bold,

                  ),

                ),
                style: ElevatedButton.styleFrom(

                  backgroundColor: Colors.purple,

                  shape: RoundedRectangleBorder(

                    borderRadius: BorderRadius.circular(20),

                  ),

                ),
                  
                onPressed: () {

                  Navigator.push(

                    context,

                    MaterialPageRoute(

                      builder: (_) => const WallpaperMenu(),

                    ),

                  );

                },

              ),

            ),
              
                        const SizedBox(height: 35),

            SizedBox(

              width: double.infinity,

              height: 120,

              child: ElevatedButton.icon(

                icon: const Icon(Icons.format_quote,

                    color: Colors.white,

                    size: 35),

                label: const Text(

                  "BTS Quotes",

                  style: TextStyle(

                    color: Colors.white,

                    fontSize: 24,

                    fontWeight: FontWeight.bold,

                  ),

                ), 
                  
                 style: ElevatedButton.styleFrom(

                  backgroundColor: Colors.deepPurple,

                  shape: RoundedRectangleBorder(

                    borderRadius: BorderRadius.circular(20),

                  ),

                ),
                onPressed: () {

                  Navigator.push(

                    context,

                    MaterialPageRoute(

                      builder: (_) => const QuotesMenu(),

                    ),

                  );

                },

              ),

            ),
              
            homeCard(

context,

"Daily Wallpaper",

Icons.auto_awesome,

GalleryScreen(

title: "Wallpaper of the Day",

category: "daily",

isQuotes: false,

),

),

            

          ],

        ),

      ),

    );

  }

}
Widget homeCard(

  BuildContext context,

  String title,

  IconData icon,

  Widget screen,

) {

  return InkWell(

    borderRadius: BorderRadius.circular(25),

    onTap: () {

      Navigator.push(

        context,

        MaterialPageRoute(

          builder: (_) => screen,

        ),

      );

    },
    child: Container(

      decoration: BoxDecoration(

        color: Colors.white.withOpacity(.18),

        borderRadius: BorderRadius.circular(25),

      ),

      child: Column(

        mainAxisAlignment: MainAxisAlignment.center,

        children: [

          Icon(

            icon,

            color: Colors.white,

            size: 45,

          ),

          const SizedBox(height: 12),

          Text(

            title,

            style: const TextStyle(

              color: Colors.white,

              fontSize: 18,

              fontWeight: FontWeight.bold,

            ),

          ),

        ],

      ),

    ),

  );

}