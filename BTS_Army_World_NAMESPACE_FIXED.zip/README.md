# bts_army_wallpaper

A new Flutter project created with FlutLab - https://flutlab.io

## Getting Started

A few resources to get you started if this is your first Flutter project:

- https://flutter.dev/docs/get-started/codelab
- https://flutter.dev/docs/cookbook

For help getting started with Flutter, view our
https://flutter.dev/docs, which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Getting Started: FlutLab - Flutter Online IDE

- How to use FlutLab? Please, view our https://flutlab.io/docs
- Join the discussion and conversation on https://flutlab.io/residents

## GitHub APK build
Use the workflow `.github/workflows/build.yml` from GitHub Actions and choose **Run workflow**.
The workflow patches the legacy `flutter_wallpaper_manager 0.0.4` Android namespace after `flutter pub get`, then builds the release APK.
