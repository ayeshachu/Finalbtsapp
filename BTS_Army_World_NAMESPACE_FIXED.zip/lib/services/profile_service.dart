import 'package:shared_preferences/shared_preferences.dart';
class ProfileService {

  static Future<void> save({

    required String name,

    required String bias,

    required String country,

    required String song,

    required String album,

  }) async {

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setString("name", name);

    await prefs.setString("bias", bias);

    await prefs.setString("country", country);

    await prefs.setString("song", song);

    await prefs.setString("album", album);

  }

  static Future<Map<String,String>> load() async {

    final prefs =
        await SharedPreferences.getInstance();

    return {

      "name":prefs.getString("name")??"ARMY",

      "bias":prefs.getString("bias")??"Jungkook",

      "country":prefs.getString("country")??"Pakistan",

      "song":prefs.getString("song")??"Spring Day",

      "album":prefs.getString("album")??"Proof",

    };

  }

}