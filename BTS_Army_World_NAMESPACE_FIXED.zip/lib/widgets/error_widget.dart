import 'package:flutter/material.dart';

class ErrorWidgetBox extends StatelessWidget {

  final String message;

  const ErrorWidgetBox({

    super.key,

    required this.message,

  });

  @override
  Widget build(BuildContext context) {

    return Center(

      child: Column(

        mainAxisAlignment:
            MainAxisAlignment.center,

        children: [

          const Icon(
            Icons.error_outline,
            size: 70,
            color: Colors.red,
          ),

          const SizedBox(height:20),

          Text(message),

        ],

      ),

    );

  }

}