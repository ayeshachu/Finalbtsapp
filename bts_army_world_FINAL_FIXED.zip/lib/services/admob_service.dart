class AdMobService {

  // Test Banner Ad Unit ID
  static String get bannerAdUnitId =>
      "ca-app-pub-3940256099942544/6300978111";

  // Test Interstitial Ad Unit ID
  static String get interstitialAdUnitId =>
      "ca-app-pub-3940256099942544/1033173712";

  // Test Rewarded Ad Unit ID
  static String get rewardedAdUnitId =>
      "ca-app-pub-3940256099942544/5224354917";
}