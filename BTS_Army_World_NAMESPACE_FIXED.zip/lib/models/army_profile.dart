class ArmyProfile {

  String name;

  String bias;

  String country;

  String favoriteSong;

  String favoriteAlbum;

  ArmyProfile({

    required this.name,

    required this.bias,

    required this.country,

    required this.favoriteSong,

    required this.favoriteAlbum,

  });

}