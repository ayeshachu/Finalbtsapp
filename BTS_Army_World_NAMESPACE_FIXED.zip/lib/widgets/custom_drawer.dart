import '../screens/contact_screen.dart';
import '../screens/privacy_policy_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/feedback_screen.dart';
import '../screens/settings_screen.dart';
import '../screens/about_screen.dart';
import 'package:flutter/material.dart';

import '../screens/favorites_screen.dart';
import '../screens/search_screen.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [

          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(top: 50, bottom: 20),
            color: Colors.purple,
            child: const Column(
              children: [

                CircleAvatar(
                  radius: 40,
                  backgroundColor: Colors.white,
                  child: Icon(
                    Icons.favorite,
                    color: Colors.purple,
                    size: 45,
                  ),
                ),

                SizedBox(height: 10),

                Text(
                  "BTS Army World",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                  
                Text(
                  "Made with 💜 for ARMY",
                  style: TextStyle(color: Colors.white70),
                ),

              ],
            ),
          ),
            
          ListTile(
  leading: const Icon(Icons.mail),
  title: const Text("Contact Us"),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const ContactScreen(),
      ),
    );
  },
),

ListTile(
  leading: const Icon(Icons.privacy_tip),
  title: const Text("Privacy Policy"),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const PrivacyPolicyScreen(),
      ),
    );
  },
),
            
          ListTile(

leading:const Icon(Icons.person),
title:const Text("My Profile"),

onTap:(){

Navigator.push(

context,

MaterialPageRoute(

builder:(_)=>const ProfileScreen(),

),

);

},

),

          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text("Favorites"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const FavoritesScreen(),
                ),
              );
           },
          ),

          ListTile(
            leading: const Icon(Icons.search),
            title: const Text("Search"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SearchScreen(),
                ),    
               );
            },
          ),

          // --- YAHAN SE NAYA CODE ADD KIYA HAI ---
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text("Settings"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SettingsScreen(),
                ),
              );
            },
          ),

          ListTile(
            leading: const Icon(Icons.info),
            title: const Text("About"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AboutScreen(),
                ),
              );
            },
          ),
          ListTile(

  leading: const Icon(Icons.feedback),

  title: const Text("Feedback"),

  onTap: (){

    Navigator.push(
      context,

      MaterialPageRoute(

        builder: (_)=>const FeedbackScreen(),

      ),

    );

  },

),

          const Divider(),

          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text("Version 1.0"),
          ),

        ],
      ),
    );
  }
}                
        