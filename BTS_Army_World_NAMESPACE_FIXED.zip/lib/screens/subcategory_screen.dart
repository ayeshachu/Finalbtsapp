import 'package:flutter/material.dart';

import 'gallery_screen.dart';

class SubCategoryScreen extends StatelessWidget {

  final String title;

  final List<String> subCategories;

  const SubCategoryScreen({

    super.key,

    required this.title,

    required this.subCategories,

  });

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text(title),

        backgroundColor: Colors.purple,

      ),

      body: ListView.builder(

        padding: const EdgeInsets.all(15),

        itemCount: subCategories.length,

        itemBuilder: (context, index) {

          final sub = subCategories[index];
                      String category =

              "${title.replaceAll(' Wallpaper', '').replaceAll(' ', '').toLowerCase()}_${sub.toLowerCase()}";

          return Card(

            child: ListTile(

              title: Text(sub),

              trailing: const Icon(Icons.arrow_forward_ios),

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (_) => GalleryScreen(

                      title: "$title - $sub",

                      category: category,

                      isQuotes: false,

                    ),

                  ),

                );

              },

            ),

          );

        },

      ),

    );

  }

}