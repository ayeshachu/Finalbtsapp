import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

class DownloadService {

  static Future<File> downloadImage(String url) async {

    Directory dir = await getTemporaryDirectory();

    String path =
        "${dir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg";

    await Dio().download(url, path);

    return File(path);

  }

}