import 'package:flutter/material.dart';
import '../widgets/error_widget.dart';

import '../widgets/loading_widget.dart';

import '../widgets/banner_ad_widget.dart';

import '../widgets/no_data_widget.dart';

import '../widgets/shimmer_loading.dart'; // FIX 1: Ye import add kiya

import 'package:flutter/material.dart';

import 'package:cached_network_image/cached_network_image.dart';

import '../services/sheet_service.dart';

import 'image_view_screen.dart';

class GalleryScreen extends StatefulWidget {

  final String title;

  final String category;

  final bool isQuotes;

  const GalleryScreen({

    super.key,

    required this.title,

    required this.category,

    required this.isQuotes,

  });

  @override

  State<GalleryScreen> createState() => _GalleryScreenState();

}

class _GalleryScreenState extends State<GalleryScreen> {

  late Future<List<String>> images;

  @override

  void initState() {

    super.initState();

    images = SheetService().getImages(

      widget.category,

      widget.isQuotes,

    );

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text(widget.title),

        backgroundColor: Colors.purple,

      ),

      body: FutureBuilder<List<String>>(

        future: images,

        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {

            return ShimmerLoading(); // FIX 2: const hata diya

          }

          if (snapshot.hasError) {

            return ErrorWidgetBox( // FIX 2: const hata diya

              message: "Network Error",

            );

          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {

            return NoDataWidget( // FIX 2: const hata diya

              text: "No Images Found",

            );

          }

          final imageList = snapshot.data!;

          return Column(

            children: [

              Expanded(

                child: RefreshIndicator(

                  onRefresh: () async {

                    setState(() {

                      images = SheetService().getImages(

                        widget.category,

                        widget.isQuotes,

                      );

                    });

                  },

                  child: GridView.builder(

                    padding: const EdgeInsets.all(10),

                    itemCount: imageList.length,

                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(

                      crossAxisCount: 2,

                      crossAxisSpacing: 10,

                      mainAxisSpacing: 10,

                    ),

                    itemBuilder: (context, index) {

                      return GestureDetector(

                        onTap: () {

                          Navigator.push(

                            context,

                            MaterialPageRoute(
                                builder: (_) => ImageViewScreen(

                                imageUrl: imageList[index],

                              ),

                            ),

                          );

                        },

                        child: Hero(

                          tag: imageList[index],

                          child: ClipRRect(

                            borderRadius: BorderRadius.circular(15),

                            child: CachedNetworkImage(

                              imageUrl: imageList[index],

                              fit: BoxFit.cover,

                              filterQuality: FilterQuality.medium,

                              fadeInDuration: Duration(milliseconds: 300),

                              memCacheHeight: 600,

                              placeholder: (context, url) => const Center(

                                child: CircularProgressIndicator(),

                              ),

                              errorWidget: (context, url, error) =>

                                  const Icon(Icons.error),

                            ),

                          ),

                        ),

                      );

                    },

                  ),

                ),

              ),

              const BannerAdWidget(),

            ],

          );

        },

      ),

    );

  }

}        