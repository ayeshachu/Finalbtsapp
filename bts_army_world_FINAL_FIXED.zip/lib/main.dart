import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/app_theme.dart';

import '../utils/constants.dart'; // agar constants use kar rahe ho toimport 'package:google_mobile_ads/google_mobile_ads.dart';

import 'package:flutter/material.dart';

import 'screens/splash_screen.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  await MobileAds.instance.initialize();

  runApp(const BTSArmyWorld());

}

class BTSArmyWorld extends StatelessWidget {

  const BTSArmyWorld({super.key});

  @override

  Widget build(BuildContext context) {

    return MaterialApp(

      debugShowCheckedModeBanner: false,

      title: 'BTS Army World',

      theme: AppTheme.light,

      home: const SplashScreen(),

    );

  }

}