import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {

  const ProfileScreen({super.key});

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text("My ARMY Profile"),

        backgroundColor: Colors.purple,

      ),

      body: ListView(

        padding: const EdgeInsets.all(20),

        children: [

          const CircleAvatar(

            radius: 50,

            child: Icon(Icons.person,size:50),

          ),

          const SizedBox(height:25),

          profileTile("Name"),

          profileTile("Bias"),

          profileTile("Country"),

          profileTile("Favorite Song"),

          profileTile("Favorite Album"),

        ],

      ),

    );
   
  }

}

Widget profileTile(String title){

  return Card(

    child: ListTile(

      leading: const Icon(Icons.favorite),

      title: Text(title),

      subtitle: const Text("Tap to Edit"),

    ),

  );

}