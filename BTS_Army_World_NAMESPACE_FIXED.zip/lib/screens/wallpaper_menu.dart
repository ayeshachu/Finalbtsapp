import 'package:flutter/material.dart';
import 'subcategory_screen.dart';

class WallpaperMenu extends StatelessWidget {

  const WallpaperMenu({super.key});

  @override

  Widget build(BuildContext context) {

    final List<Map<String, dynamic>> categories = [

      {

        "title":"BTS Wallpaper",

        "subs":["Cute","Aesthetic","Arrirang"]

      },

      {

        "title":"JK Wallpaper",

        "subs":["Cute","Hot","Eyes","Aesthetic"]

      },

      {

        "title":"V Wallpaper",

        "subs":["Cute","Hot","Aesthetic"]

      },

      {

        "title":"Jimin Wallpaper",

        "subs":["Cute","Hot","Aesthetic"]

      },

      {

        "title":"Suga Wallpaper",

        "subs":["Cute","AgustD","Aesthetic"]

      },

      {

        "title":"Jhope Wallpaper",
        
        "subs":["Cute","Hot","Aesthetic"]

      },

      {

        "title":"RM Wallpaper",

        "subs":["Cute","Hot","Aesthetic"]

      },

      {

        "title":"Jin Wallpaper",

        "subs":["Cute","Hot","Aesthetic"]

      },

      {

        "title":"Taekook Wallpaper",

        "subs":[]

      },

      {

        "title":"Yoonmin Wallpaper",

        "subs":[]

      },

      {

        "title":"Namjin Wallpaper",

        "subs":[]

      },

      {

        "title":"Yoonkook Wallpaper",

        "subs":[]

      },

      {

        "title":"Jikook Wallpaper",

        "subs":[]

      },

      {

        "title":"Jinkook Wallpaper",

        "subs":[]

      },

      {

        "title":"Jinmin Wallpaper",   
        
        "subs":[]

      },

      {

        "title":"Vmin Wallpaper",

        "subs":[]

      },

      {

        "title":"Vjin Wallpaper",

        "subs":[]

      },

    ];

    return Scaffold(

      appBar: AppBar(

        title: const Text(

          "Wallpaper Categories",

          style: TextStyle(color: Colors.white),

        ),

        centerTitle: true,

        backgroundColor: Colors.purple,

      ),

      body: Padding(

        padding: const EdgeInsets.all(12),

        child: GridView.builder(

          itemCount: categories.length,

          gridDelegate:

          const SliverGridDelegateWithFixedCrossAxisCount(
              
            crossAxisCount: 2,

            crossAxisSpacing: 12,

            mainAxisSpacing: 12,

          ),

          itemBuilder: (context,index){

            return ElevatedButton(

              style: ElevatedButton.styleFrom(

                backgroundColor: Colors.purple,

                shape: RoundedRectangleBorder(

                  borderRadius:

                  BorderRadius.circular(18),

                ),

              ),

              onPressed: (){

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder:(_)=>SubCategoryScreen(

                      title: categories[index]["title"],
subCategories:

                      List<String>.from(

                          categories[index]["subs"]),

                    ),

                  ),

                );

              },

              child: Text(

                categories[index]["title"],

                textAlign: TextAlign.center,

                style: const TextStyle(

                  color: Colors.white,

                  fontWeight: FontWeight.bold,

                  fontSize: 17,

                ),

              ),

            );

          },

        ),

      ),

    );

  }

}                        