import 'package:flutter/material.dart';

class NoDataWidget extends StatelessWidget {

  final String text;

  const NoDataWidget({
    super.key,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {

    return Center(
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [

          const Icon(
            Icons.image_not_supported,
            size: 70,
            color: Colors.grey,
          ),

          const SizedBox(height: 15),

          Text(
            text,
            style: const TextStyle(
              fontSize: 18,
            ),
          ),

        ],
      ),
    );

  }
}